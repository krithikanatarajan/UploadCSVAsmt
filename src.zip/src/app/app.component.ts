import { Component } from '@angular/core';
import {minimalIssuePipe } from './app.pipe';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[minimalIssuePipe]
})
export class AppComponent {
  title = 'UploadProject';
  csvContent: any;
    txtFtrMinIssueCnt:number;
  onFileLoad(fileLoadedEvent) 
  {
    const textFromFileLoaded = fileLoadedEvent.target.result;      
   localStorage.setItem('strCSV',textFromFileLoaded)
     
}
onFileSelect(input: HTMLInputElement) {

const files = input.files;
var content = this.csvContent;    
if (files && files.length) {
  const fileReader = new FileReader();
  fileReader.onload = this.onFileLoad;

  fileReader.readAsText(files[0], "UTF-8");
  this.csvJSON();
}

}
csvJSON(){
  
var csv=localStorage.getItem('strCSV').toString().replace(/\r/g, '');
  var lines=csv.split("\n");

  var result = [];

  var headers=lines[0].replace(/\"/g, '').replace(/\ /g,'').split(",");

  for(var i=1;i<lines.length;i++){
	  var obj = {};
	  var currentline=lines[i].split(",");

	  for(var j=0;j<headers.length;j++){
      obj[headers[j]] = currentline[j].replace(/\"/g, '');
      if(j==3)
        {
          obj[headers[j]] =new Date(currentline[j].replace(/\"/g, '').substring(0,10));
        }
        else
        {
          obj[headers[j]] = currentline[j].replace(/\"/g, '');
        }
	  }
    result.push(obj);
  }
  console.log(JSON.stringify(result));
  this.csvContent= result; //JSON
  }

}
